<?php

class config {
	const DB_SERVER    = '127.0.0.1';
	const DB_NAME      = 'lab1';
	const DB_USERNAME  = 'root';
	const DB_PASSWORD  = '';
	const DB_PREFIX	   = '';
	const NUMBER_OF_ROWS_IN_PAGE = 10;
}

?>
