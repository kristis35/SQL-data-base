<?php


// įtraukiame šabloną
include 'templates/home_page.tpl.php';

?>