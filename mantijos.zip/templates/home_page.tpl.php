<div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
	
	<div class="feature col">
		<h2>Paslaugos</h2>
		<p>Teikiamų paslaugų peržiūra, įrašymas, redagavimas.</p>
		<a href="index.php?module=service&action=list" class="icon-link">
			Atidaryti
		</a>
	</div>
	<div class="feature col">
		<h2>Klientai</h2>
		<p>Klientų peržiūra, registravimas, redagavimas.</p>
		<a href="index.php?module=customer&action=list" class="icon-link">
			Atidaryti
		</a>
	</div>
	<div class="feature col">
		<h2>Dalinimo vietos</h2>
		<p>Dalinimo vietu peržiūra, registravimas, redagavimas.</p>
		<a href="index.php?module=model&action=list" class="icon-link">
			Atidaryti
		</a>
	</div>
	
</div>

<div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
	
	<div class="feature col">
		<h2>Mantijos</h2>
		<p>Nuomojamų mantiju peržiūra, įrašymas, redagavimas.</p>
		<a href="index.php?module=car&action=list" class="icon-link">
			Atidaryti
		</a>
	</div>
	<div class="feature col">
		<h2>Miestai</h2>
		<p>Miestu klasifikatoriaus administravimas.</p>
		<a href="index.php?module=brand&action=list" class="icon-link">
			Atidaryti
		</a>
	</div>
</div>
